#!/bin/bash
# BEGIN SGE OPTIONS DECLARATIONS
# Export all environment variables
#$ -V
#
#$ -v TMPDIR=/data
# Your job name
#$ -N run12
#
# Shell Environment
#$ -S /bin/bash
#
# Use current working directory
#$ -cwd
#
#Output files for stdout and stderr
#$ -o run12
#$ -e run12
#
# Ask for this many slots for multi-threaded jobs:
#$ -pe thread 16
#
# END SGE OPTIONS DECLARATIONS
#
PATH=/local/cluster/sge/bin/lx-amd64:/local/cluster/sge/bin:/local/cluster/sge/bin/lx-amd64:/local/cluster/sge/bin:/local/cluster/sge/bin/lx-amd64:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/bin:/usr/bin:/usr/X11R6/bin:/usr/X/bin:/usr/local/bin:/home/users/tann/scripts:/home/users/tann/bin:/local/cluster/bin:./:/home/users/tann/bin:/home/users/tann/bin:/home/users/tann/scripts:/usr/local/bin:/usr/bin:/bin:/local/cluster/bin:/local/cluster/genome/bin:/local/cluster/mpich/bin:/usr/local/share/ncbi/bin:/local/cluster/RAxML/bin:/local/cluster/velvet/velvet:/local/cluster/abyss/bin:/local/cluster/edena2.1.1_linux64:/local/cluster/RECON1.05/scripts:/usr/X11R6/bin:/usr/X/bin:/local/cluster/mockler/bin:/local/cluster/454/bin:/local/cluster/trinityrnaseq
export PATH
#
#
#The following auto-generated commands will be run by the execution node.
#We execute your command via /usr/bin/time with a custom format
#so that the memory usage and other stats can be tracked; note that
#GNU time v1.7 has a bug in that it reports 4X too much memory usage
echo "  Started on:           " `/bin/hostname -s` 
echo "  Started at:           " `/bin/date` 
/usr/bin/time -f " \\tFull Command:                      %C \\n\\tMemory (kb):                       %M \\n\\t# SWAP  (freq):                    %W \\n\\t# Waits (freq):                    %w \\n\\tCPU (percent):                     %P \\n\\tTime (seconds):                    %e \\n\\tTime (hh:mm:ss.ms):                %E \\n\\tSystem CPU Time (seconds):         %S \\n\\tUser   CPU Time (seconds):         %U " \
python3 cifar10_cnn4.py
echo "  Finished at:           " `date` 
