import numpy as np
import matplotlib.pyplot as plt
from itertools import chain

train = open("run17/train_acc.txt", 'r')  # Change it accordingly
train_x = [line.split(',') for line in train.readlines()]

val = open("run17/val_acc.txt", 'r')  # Change it accordingly
val_x = [line.split(',') for line in val.readlines()]

tx = list(chain.from_iterable(train_x))
vx = list(chain.from_iterable(val_x))

tx.pop(50)
vx.pop(50)

t_acc = [float(x) for x in tx]
v_acc = [float(x) for x in vx]

# Plot
plt.plot(v_acc)
plt.plot(t_acc)
plt.legend(['val_acc', 'train_acc'], loc='upper left')
plt.title("Train and Val. Accuracy by Epochs")
plt.ylabel("Accuracy")
plt.xlabel("Epochs")
plt.draw()
plt.savefig('graph.png')
plt.show()
