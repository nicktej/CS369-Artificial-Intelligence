import matplotlib.pyplot as plt
import pickle


def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


datas_dir = '/Users/nicktan/PycharmProjects/cifar10/cifar-10-batches-py/data_batch_1'
x = unpickle(datas_dir)

# print(type((x[b'data'][43][2048])/255))
# x is the CIFAR-10 batch 1 dictionary
# b'data' is the key in the dictionary for the array of rgb values
# p is the picture we want to look at
# n is the pixel number

n = 0
p = 42
j = 1
q = 31

for i in range(0, 33):
   r = (x[b'data'][p][i]) / 255
   g = (x[b'data'][p][i + 1024]) / 255
   b = (x[b'data'][p][i + 2048]) / 255
   plt.scatter(i, 32, c=(r, g, b), s=42, marker=",")

for j in range(1,31):
   for i in range(0, 33):
      r = (x[b'data'][p][i + 32*j]) / 255
      g = (x[b'data'][p][i + 32*j + 1024]) / 255
      b = (x[b'data'][p][i + 32*j + 2048]) / 255
      plt.scatter(i, q, c=(r, g, b), s=42, marker=",")
   q = q - 1


plt.xlim(-1, 33)
plt.ylim(-1, 33)
plt.show()
